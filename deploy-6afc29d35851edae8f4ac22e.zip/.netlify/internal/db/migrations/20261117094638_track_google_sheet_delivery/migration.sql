ALTER TABLE "census_submissions" ADD COLUMN "sheet_synced" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "census_submissions" ADD COLUMN "sheet_sync_until" timestamp with time zone;