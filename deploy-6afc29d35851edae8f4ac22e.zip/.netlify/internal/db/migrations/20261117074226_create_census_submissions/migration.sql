CREATE TABLE "census_submissions" (
	"reference" text PRIMARY KEY,
	"session_hash" text NOT NULL,
	"submitted_at" timestamp with time zone DEFAULT now() NOT NULL,
	"records" jsonb NOT NULL,
	"dispatched" jsonb DEFAULT '[]' NOT NULL
);
